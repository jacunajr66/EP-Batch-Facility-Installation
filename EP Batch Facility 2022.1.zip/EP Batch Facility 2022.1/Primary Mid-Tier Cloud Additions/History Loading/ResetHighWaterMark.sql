BEGIN
    EXECUTE IMMEDIATE 'truncate table pf_sys_dutransdate';
END;